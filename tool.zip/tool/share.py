import os
import sys
import aiohttp
import asyncio
import datetime
from rich.console import Console
from rich.text import Text

if sys.platform == 'win32':
    asyncio.set_event_loop_policy(asyncio.WindowsSelectorEventLoopPolicy())

console = Console()

def read_lines_from_file(filename):
    try:
        with open(filename, 'r') as f:
            lines = f.readlines()
            return [line.strip() for line in lines if line.strip()]
    except FileNotFoundError:
        console.print(f"[red]File {filename} không tồn tại.")
        return []

def banner():
    os.system('cls' if os.name == 'nt' else 'clear')
    ban = Text("""
[ Tool Share By TatsuYTB ]
""")
    ban.stylize("bold bright_green", 1, 29)
    ban.stylize("bold bright_red", 0, 1)
    console.print(ban)

success_count = 0

async def getid(session, link):
    try:
        async with session.post('https://id.traodoisub.com/api.php', data={"link": link}) as response:
            rq = await response.json()
            if 'success' in rq:
                return rq["id"]
            else:
                console.print(f"[red]Link post sai hoặc lỗi lấy ID!!!")
                sys.exit()
    except Exception as e:
        console.print(f"[red]Lỗi kết nối lấy ID: {e}")
        sys.exit()

async def get_token(session, token, cookie):
    headers = {
        'authority': 'graph.facebook.com',
        'cache-control': 'max-age=0',
        'sec-ch-ua': '"Google Chrome";v="125", "Chromium";v="125", "Not.A/Brand";v="24"',
        'sec-ch-ua-mobile': '?0',
        'sec-ch-ua-platform': '"Windows"',
        'upgrade-insecure-requests': '1',
        'user-agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/125.0.0.0 Safari/537.36',
        'accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3;q=0.7',
        'sec-fetch-site': 'none',
        'sec-fetch-mode': 'navigate',
        'sec-fetch-user': '?1',
        'sec-fetch-dest': 'document',
        'accept-language': 'vi-VN,vi;q=0.9,fr-FR;q=0.8,fr;q=0.7,en-US;q=0.6,en;q=0.5',
        'cookie': cookie
    }
    params = {'access_token': token}
    try:
        async with session.get('https://graph.facebook.com/me/accounts', params=params, headers=headers) as r:
            rq = await r.json()
            if 'data' in rq:
                return rq
            return {}
    except:
        return {}

async def share_single_post(session, tk, ck, post):
    url = f'https://graph.facebook.com/me/feed?method=POST&link=https://m.facebook.com/{post}&published=0&access_token={tk}'
    
    headers = {
        'authority': 'graph.facebook.com',
        'accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3;q=0.7',
        'accept-language': 'vi-VN,vi;q=0.9,fr-FR;q=0.8,fr;q=0.7,en-US;q=0.6,en;q=0.5',
        'cache-control': 'max-age=0',
        'cookie': ck,
        'priority': 'u=0, i',
        'sec-ch-ua': '"Google Chrome";v="125", "Chromium";v="125", "Not.A/Brand";v="24"',
        'sec-ch-ua-mobile': '?0',
        'sec-ch-ua-platform': '"Windows"',
        'sec-fetch-dest': 'document',
        'sec-fetch-mode': 'navigate',
        'sec-fetch-site': 'none',
        'sec-fetch-user': '?1',
        'upgrade-insecure-requests': '1',
        'user-agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/125.0.0.0 Safari/537.36'
    }

    try:
        async with session.get(url, headers=headers) as response:
            json_data = await response.json()
            if 'id' in json_data:
                return True, json_data.get('id', 'N/A')
            else:
                return False, json_data.get('error', {}).get('message', 'Unknown error')
    except Exception as e:
        return False, str(e)

async def share_loop(session, tk, ck, post, page_id, limit, delay, sem):
    global success_count
    
    while True:
        if limit is not None and success_count >= limit:
            break

        try:
            async with sem:
                is_success, result = await share_single_post(session, tk, ck, post)
            
            now = datetime.datetime.now().strftime("%H:%M:%S")

            if is_success:
                success_count += 1
                console.print(f"[green]| Thành công | [magenta]{now} | [blue]{page_id} | [yellow]Tổng: {success_count}")
                
                if limit is not None and success_count >= limit:
                    console.print(f"\n[bold bright_green]Đã đạt đủ {limit} share. Dừng tool!")
                    sys.exit(0)
                
                await asyncio.sleep(delay)
            else:
                console.print(f"[red]| Thất bại | [magenta]{now} | [blue]{page_id} | [white]Lỗi: {result}")
                console.print(f"[yellow]=> Page {page_id} bị chặn/lỗi. Nghỉ 10 phút...")
                await asyncio.sleep(600) 

        except Exception as e:
            console.print(f"[red]| Lỗi mạng | {page_id} | {e} | Retry 60s...")
            await asyncio.sleep(60)

async def main(link, limit, delay):
    banner()
    
    connector = aiohttp.TCPConnector(limit=None, ssl=False)
    
    async with aiohttp.ClientSession(connector=connector) as session:
        post = await getid(session, link)
        
        cookies = read_lines_from_file('cookie.txt')
        tokens = read_lines_from_file('token.txt')
        
        if not cookies or not tokens:
            console.print("[red]Thiếu file cookie.txt hoặc token.txt")
            sys.exit()
        
        list_pages = []
        
        for token in tokens:
            ck = cookies[0] 
            token_data = await get_token(session, token, ck)
            if 'data' in token_data:
                for page in token_data['data']:
                    list_pages.append({"tk": page["access_token"], "id": page["id"], "ck": ck})
        
        if not list_pages:
            console.print("[red]Không tìm thấy Page nào!")
            sys.exit()
            
        banner()
        console.print(f"[magenta]Tổng Page: [yellow]{len(list_pages)}")
        
        MAX_CONCURRENT_REQUESTS = 5 # tốc
        sem = asyncio.Semaphore(MAX_CONCURRENT_REQUESTS)
        
        tasks = []
        console.print(f"[green]Đang khởi chạy {len(list_pages)} page (Delay {delay}s/page)...")
        
        for page in list_pages:
            tasks.append(asyncio.create_task(share_loop(session, page["tk"], page["ck"], post, page["id"], limit, delay, sem)))
            await asyncio.sleep(delay)
            
        await asyncio.gather(*tasks)

if __name__ == "__main__":
    banner()
    link = console.input("[green]Link Post: [yellow]")
    limit_input = console.input("[green]Số lượng: [yellow]")
    
    limit = int(limit_input) if limit_input.strip() else None
    
    delay = 2.5
    
    try:
        asyncio.run(main(link, limit, delay))
    except KeyboardInterrupt:
        print("\nĐã dừng tool.")
    except Exception as e:
        print(f"Lỗi: {e}")